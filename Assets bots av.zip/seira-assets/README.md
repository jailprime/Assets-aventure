# Assets de Seira Aventure

À pousser tel quel à la racine d'un dépôt GitHub **public** (le nom `compte/depot` va dans `ASSETS_REPO` du bot).

```
visuels/
  start-base.png            visuel « Commencer l'aventure » (le bot écrit le texte dessus)
  eveil-base.png            panel d'éveil des 15 classes
  apparence-base.png        visuel « Choisis ton apparence » (le bot incruste le portrait dans le cercle central)
icones/cheveux/<couleur>.png    pastilles de cheveux, 128 x 128, fond transparent
                                (noir, brun, blond, rouge, argent)
```

Les portraits (`personnages/`) et les animations d'éveil (`animations/eveil/`) ne sont **pas** ici : ils sont à la racine du bot, sur le VPS.

Classes : `aventurier mage archer pretre assassin chevalier paladin commercant artisan player-killer mineur conjurateur sorciere alchimiste forgeron`.
Genres : `homme`, `femme`. Emplacement `n` : 1 à 5, dans l'ordre des pastilles du visuel (pas de couleur de cheveux imposée ;
j'ai rangé les portraits dans l'ordre noir, brun, blond, rouge, argent quand c'était possible).

## Pousser sur GitHub

```bash
cd seira-assets
git init -b main
git add .
git commit -m "Assets de Seira Aventure"
git remote add origin https://github.com/TON-COMPTE/seira-assets.git
git push -u origin main
```

Après un changement d'image, utilise un tag (`git tag v2 && git push --tags`) et mets-le dans `ASSETS_REF` : GitHub met les fichiers en cache
quelques minutes, un tag évite d'afficher une ancienne version.

